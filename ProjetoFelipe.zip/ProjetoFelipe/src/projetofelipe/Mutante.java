/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetofelipe;

/**
 *
 * @author Pedro Braga
 */
public class Mutante implements Estado, Observador  {
    
    private Dao dao;
    private String kill;
    
    @Override
    public void bater(){
        
        System.out.println("Bate rapido");
    }
    
    @Override
    public void defender(){
           System.out.println("Se defende melhor");
    
    }
    
    @Override
    public void notificar(){
        
        System.out.println("Notificação: sua classe é > Mutante !!");
    }

    @Override
    public void notificar(Object novoValor) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

      
        
   
}

