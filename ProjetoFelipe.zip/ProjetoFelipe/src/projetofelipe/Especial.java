/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetofelipe;

/**
 *
 * @author Pedro Braga
 */
public abstract class Especial  {
    
    public void EspecialKill(){
        
        correr();
        pular();
        chutar();
                
    }
    
    public void correr(){
        System.out.println("Corrida executada");
    }
    
    public void pular(){
        System.out.println("Pulo concretizado");
        
    }
    
    public abstract void chutar();
    
}
