/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetofelipe;

/**
 *
 * @author Pedro Braga
 */
public class ProjetoFelipe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Estado //especial //Observador //Strategy
        Orc o = new Orc();
        Especial x = new ChuteMortal();
        
        o.setEstado(new Mutante());
        o.bater();
        o.defender();
        System.out.println("---Notificando---");
        o.notificacao(new Normal());
        o.setNome("Mutante");
        System.out.println("---Tipo de Ataque---");
        o.setJeitoDeAtaque(new AtaqueDeMachado());
        o.ataque();
        System.out.println("---Especial---");
        x.EspecialKill();
       
       
        
        
        
    }
    
}
