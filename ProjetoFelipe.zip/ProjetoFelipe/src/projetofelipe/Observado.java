/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetofelipe;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Pedro Braga
 */
public class Observado {
    
     private List<Observador> listaDeObservadores = new ArrayList<>();
    /* opcional*/
    private String descricao;
    private String nome;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
        notifcarTodos(nome);
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
        notifcarTodos(descricao);
    }
    /*opcional*/

    private void notifcarTodos(Object novoValor) {
        for (Observador observador : listaDeObservadores) {
            observador.notificar();
            observador.notificar(novoValor);
        }
    }

    public void inscrever(Observador observador) {
        listaDeObservadores.add(observador);
    }
    
}
