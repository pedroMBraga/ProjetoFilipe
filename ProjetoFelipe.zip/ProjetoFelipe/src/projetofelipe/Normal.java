/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetofelipe;

/**
 *
 * @author Pedro Braga
 */
public class Normal implements Estado, Observador {
    
    
    @Override
    public void bater(){
        
        System.out.println("Bate normal");
    }
    
    @Override
    public void defender(){
           System.out.println("Se defende normal");
           
    }
     
    @Override
    public void notificar(){
        
        System.out.println("Notificação: sua classe é > Normal !!!!");
    }

    @Override
    public void notificar(Object novoValor) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
    
    
}
